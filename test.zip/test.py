print("Hello World!")
print("恭喜你在编程的世界里迈出了新的一步！愿你的代码之路充满创意和成功。")
